cordova.define("cordova-plugin-device-orientation.CompassHeading", function(require, exports, module) { 
});
